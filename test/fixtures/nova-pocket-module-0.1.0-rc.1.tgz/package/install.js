#!/usr/bin/env node
import { cp, lstat, mkdir, mkdtemp, readFile, rename, rm, rmdir } from 'node:fs/promises'
import { basename, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const source = fileURLToPath(new URL('./', import.meta.url))
const metadata = async dir => JSON.parse(await readFile(join(dir, 'package.json'), 'utf8'))

async function install(project) {
  const src = join(resolve(project), 'src')
  if (!(await lstat(join(src, 'pages.json'))).isFile()) throw new Error('请指定含 src/pages.json 的 UniApp 项目')
  const modules = join(src, 'uni_modules')
  await mkdir(modules, { recursive: true })
  if (!(await lstat(modules)).isDirectory()) throw new Error('uni_modules 需为宿主内的实际目录')
  const { id, version } = await metadata(source)
  const target = join(modules, 'nova-pocket')
  if (resolve(source) === target) throw new Error('请从新版本的压缩包运行安装命令')
  const lock = join(modules, '.nova-pocket-install')
  await mkdir(lock)
  // Keep the old directory on disk until the replacement has been fully staged.
  const incoming = join(lock, 'incoming')
  let backup
  try {
    const existing = await lstat(target).catch(error => {
      if (error.code !== 'ENOENT') throw error
    })
    if (existing && (!existing.isDirectory() || (await metadata(target)).id !== id)) {
      throw new Error('同名目录属于其他内容：' + target)
    }
    await cp(source, incoming, { recursive: true, filter: path => basename(path) !== 'node_modules' })
    if (existing) {
      backup = await mkdtemp(join(lock, 'previous-'))
      await rename(target, join(backup, id))
    }
    try {
      await rename(incoming, target)
    } catch (error) {
      if (backup) await rename(join(backup, id), target)
      throw error
    }
    if (backup) await rm(backup, { recursive: true, force: true })
    console.log('已安装 ' + id + ' ' + version + ' → ' + target)
  } finally {
    await rm(incoming, { recursive: true, force: true })
    if (backup) await rmdir(backup).catch(() => {})
    // If restoration itself failed, preserve the previous tree for recovery.
    await rmdir(lock).catch(() => {})
  }
}

if (process.argv.length !== 3) {
  console.error('用法：install-nova-pocket <已有 UniApp 项目目录>')
  process.exitCode = 1
} else {
  await install(process.argv[2]).catch(error => {
    console.error(error.message)
    process.exitCode = 1
  })
}
